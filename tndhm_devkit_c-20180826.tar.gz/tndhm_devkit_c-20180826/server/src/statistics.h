#ifndef STATISTICS_H
#define STATISTICS_H

struct playerStatistics {
	int getStage;
	int cardStrength;
	int shibari;
	int shibariCnt;
	int fukusuu;
	int kaidan;
	int kakumei;
	int jokerTurnSum;
	int jokerCnt;
	int eightGiriTurnSum;
	int eightGiriCnt;
	int spe3;
}; 

#endif //STATISTICS_H
